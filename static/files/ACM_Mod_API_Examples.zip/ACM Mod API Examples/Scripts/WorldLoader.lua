
local ACM = sm["6adc7c70-de63-4f47-afbf-018220f548d4"]

WorldLoader = class()

function WorldLoader.sv_loadWorld( self )
	ACM.world.loadWorld( "Flat World", ACM.map.getLevelCreations(), true )	--load the flat world while keeping creations and saving the level data once it's loaded
end




function WorldLoader.client_onInteract( self, char, lookAt )
	if lookAt then
		self.network:sendToServer( "sv_loadWorld" )
	end
end

function WorldLoader.client_canInteract( self, char, lookAt )
	local use = sm.gui.getKeyBinding( "Use", true )
	sm.gui.setInteractionText( "", use, "Load 'Flat World'" )
	sm.gui.setInteractionText( "", "", "#ff0000WARNING: Creations in the world may be lost!" )	--display a warning to inform the user of the risks of switching the world while creations are in it
	return true
end
