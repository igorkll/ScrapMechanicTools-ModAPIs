
local ACM = sm["6adc7c70-de63-4f47-afbf-018220f548d4"]

CommandRegisterer = class()

function CommandRegisterer.server_onCreate( self )
	ACM.game.registerChatCommand( "/fancyCustomCommand", {}, "A fancy custom chat command registered with the ACM Mod API!" )	--register a command
	sm.gui.chatMessage( "#00ff00Custom Chat command '/fancyCustomCommand' was registered!\nThe command can be received with the Event Listener." )
end
