
local ACM = sm["6adc7c70-de63-4f47-afbf-018220f548d4"]

ChallengeInterface = class()

function ChallengeInterface.sv_switch( self, mode, player )
	if mode == 1 then
		if not ACM.map.startChallenge() then	--try to start the challenge
			self.network:sendToClient( player, "cl_failed" )
		end
	elseif mode == 2 then
		ACM.map.resetChallenge()	--reset the challenge to how it was before starting
	end
	print( "Map State is now:", ACM.map.getMapState() )	--print the map state
end



function ChallengeInterface.client_canInteract( self )
	local use, tinker = sm.gui.getKeyBinding( "Use", true ), sm.gui.getKeyBinding( "Tinker", true )
	sm.gui.setInteractionText( "", use, "Start the challenge" )
	sm.gui.setInteractionText( "", tinker, "Reset the challenge" )
	return true
end

function ChallengeInterface.client_onInteract( self, char, lookAt )
	if lookAt then
		self.network:sendToServer( "sv_switch", 1 )
	end
end

function ChallengeInterface.client_onTinker( self, char, lookAt )
	if lookAt then
		self.network:sendToServer( "sv_switch", 2 )
	end
end

function ChallengeInterface.cl_failed( self )
	sm.gui.chatMessage( "Failed to start the challenge!" )
end