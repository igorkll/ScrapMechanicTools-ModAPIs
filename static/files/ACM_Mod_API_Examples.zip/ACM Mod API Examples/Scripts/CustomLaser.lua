
local ACM = sm["6adc7c70-de63-4f47-afbf-018220f548d4"]

CustomLaser = class()

CustomLaser.connectionInput = 1
CustomLaser.connectionOutput = 1

CustomLaser.maxParentCount = 1
CustomLaser.maxChildCount = 1

function CustomLaser.server_onCreate( self )
	self.lazer = ACM.laser.createLaser()	--for the host, server and client are synced so only server needs to create a laser
end

function CustomLaser.server_onFixedUpdate( self, dt )
	local parent = self.interactable:getSingleParent()
	local active = parent and parent.active or false

	if active then
		local hitData = self.lazer:sv_fire( self.shape.worldPosition + self.shape.at * 0.125, self.shape.at, 100, false, 8, true )	--Fire the laser on the server to let it calculate reflections, etc.
																								--Firing in custom mode (4th arg is false) returns data about what it hit
																								--Firing with 'useSphereCast' (last arg is true) makes it use sphere casts instead of ray casts
		for k, data in pairs( hitData ) do	--loop though the hit data
			local shapeType = ACM.laser.getShapeType( data.shape )	--get the type of the shape

			if shapeType == "receiver" then	--If the shape is a receiver
				ACM.laser.addActiveObject( data.shape.interactable ) --Add the interactable to the active objects so the laser manager can activate the receiver

			elseif shapeType ~= "reflector" and data.shape ~= self.shape then	--if the shape is not a receiver, not a reflector and not the laser itself
				if sm.item.isBlock( data.shape.uuid ) then	--If the shape is a block
					data.shape:destroyBlock( data.shape:getClosestBlockLocalPosition( data.hitPos ), nil, 5 )	--destroy the block

				elseif sm.item.isPart( data.shape.uuid )	then	--If the shape is a part
					data.shape:destroyPart( 5 )	--destroy the part

				end
			end
		end
	end
end




function CustomLaser.client_onCreate( self )
	if not self.lazer then						--if the client is NOT the host (and thus doesn't have a laser), create their own local laser
		self.lazer = ACM.laser.createLaser()
	end
end

function CustomLaser.client_onFixedUpdate( self, dt )
	local parent = self.interactable:getSingleParent()
	local active = parent and parent.active or false

	if active then
		local hitData = self.lazer:cl_fire( self.shape.worldPosition + self.shape.at * 0.125, self.shape.at, 100, self.shape.color, 8, true )	--fire the laser on the client to make the laser beam appear in the world
		for k, data in pairs( hitData ) do	--loop through clientside hit data
			sm.particle.createParticle( "paint_smoke", data.hitPos, nil, self.shape.color )	--Create a smoke particle at the hit position of each shape
		end

	elseif self.lazer.active then
		self.lazer:cl_stop()	--Stop the laser if the parent logic is off. This is needed to make the laser beam disappear when the laser is turned off.
	end

end

function CustomLaser.client_onDestroy( self )
	self.lazer:cl_destroy()		--Destroy the laser if the interactable part is destroyed/erased/etc.
end

