
local ACM = sm["6adc7c70-de63-4f47-afbf-018220f548d4"]

SettingsChecker = class()

function SettingsChecker.server_onCreate( self )
	local maxPlayers = ACM.settings.multiplayer.getMaxPlayers()			--get various settings values, then print them to chat
	local enableNametags = ACM.settings.multiplayer.getEnableNametags()

	local playerGravity = ACM.settings.physics.getPlayerGravity()

	local healthEnabled = ACM.settings.health.getEnableHealth()
	local maxHP = ACM.settings.health.getMaxHealth()

	sm.gui.chatMessage( "#ffff00--Settings--" )
	sm.gui.chatMessage( "#ffffffMaximum Players: " .. tostring( maxPlayers ) )
	sm.gui.chatMessage( "#ffffffEnable Player Nametags: " .. tostring( enableNametags ) )
	sm.gui.chatMessage( "#ffffffPlayer Gravity: " .. tostring( playerGravity ) )
	sm.gui.chatMessage( "#ffffffHealth System Enabled: " .. tostring( healthEnabled ) )
	sm.gui.chatMessage( "#ffffffMaximum HP: " .. tostring( maxHP ) )
	
end
