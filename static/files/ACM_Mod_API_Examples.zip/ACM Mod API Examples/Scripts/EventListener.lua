
local ACM = sm["6adc7c70-de63-4f47-afbf-018220f548d4"]

EventListener = class()

function EventListener.server_onCreate( self )
	ACM.event.addEventListener( self.interactable )	--add this object as an event listener
end

function EventListener.server_onGameEvent( self, eventData )	--the server_onGameEvent callback receives the events after the object was added as listener
	sm.gui.chatMessage( "(Server) Game Event: " .. eventData.name )
end

function EventListener.server_onDestroy( self )
	ACM.event.removeEventListener( self.interactable )	--remove the object if it doesn't exist anymore
end
