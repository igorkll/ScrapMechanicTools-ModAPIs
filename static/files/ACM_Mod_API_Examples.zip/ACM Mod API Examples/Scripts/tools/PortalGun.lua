
local ACM = sm["6adc7c70-de63-4f47-afbf-018220f548d4"]

--[[
	NOTE
	This code, while it does work, has various flaws.
	For example, if multiple guns are created before any portal is fired, they interfere with each other due to the color.
	Also, you have to place the portals twice to make it link them properly and the portal rotation doesn't work properly (I can't figure this out...)

	This whole code is anything but perfect... you're way better off just using it as a resource and creating your own, better version
]]

local function generateRandomColor()	--function to generate a random color
	return sm.color.new( math.random( 100, 1000 ) / 1000, math.random( 100, 1000 ) / 1000, math.random( 100, 1000 ) / 1000 )
end

local defaultFirstColor = sm.color.new( "#df7f00" )	--default first portal color
local defaultSecondColor = sm.color.new( "#0a3ee2" ) --default second

local worldUp = sm.vec3.new( 1, 0, 0 )	--axis used for portal rotation

PortalGun = class()

function PortalGun.server_onCreate( self )
	if ACM.portal.getPortalByColor( defaultFirstColor ) or ACM.portal.getPortalByColor( defaultSecondColor ) then	--if a default color portal exists already, generate 2 random colors
		self.firstColor = generateRandomColor()
		self.secondColor = generateRandomColor()
	else	--if the default colors weren't used yet, use them
		self.firstColor = defaultFirstColor
		self.secondColor = defaultSecondColor
	end

	self.firstPortalFired = false
	self.secondPortalFired = false
end

function PortalGun.server_onFixedUpdate( self )
	if self.firstPortalFired then	--if the first portal was fired
		if not self.firstPortal then	--if the first portal wasn't created yet, create it
			self.firstPortal = ACM.portal.getPortalByColor( self.firstColor )
		end
	end

	if self.secondPortalFired then	--same thing for the second portal
		if not self.secondPortal then
			self.secondPortal = ACM.portal.getPortalByColor( self.secondColor )
		end
	end
end

function PortalGun.sv_shootPortal( self, data, player )
	local portalType = data[1]								--put the data back together
	local pos = sm.vec3.new( data[2], data[3], data[4] )
	local normal = sm.vec3.new( data[5], data[6], data[7] )

	local rot = sm.vec3.getRotation( worldUp, normal )	--calculate the rotation
														--someone fix this pls
	local targetPos = pos + normal * 0.01	--move the position slightly forward so the portal doesn't clip into the wall

	if portalType == 1 then	--if the first portal was used
		if self.firstPortal and self.firstPortal:exists() then	--if we have a first portal and the portal exists
			self.firstPortal:update( targetPos, rot )	--update the portal's position and rotation with the new data
			if self.secondPortal then					--if we have a second portal, make sure they're linked
				self.firstPortal:link( self.secondPortal )
			end
		else	--no first portal or first portal doesn't exist anymore. Set the var to nil, create a new portal and set a var allowing onFixedUpdate to see that the portal was fired
			self.firstPortal = nil
			ACM.portal.createPortal( targetPos, rot, self.firstColor )
			self.firstPortalFired = true
		end
	else	--same for the second portal
		if self.secondPortal and self.secondPortal:exists() then
			self.secondPortal:update( targetPos, rot )
			if self.firstPortal then
				self.secondPortal:link( self.firstPortal )
			end
		else
			self.secondPortal = nil
			ACM.portal.createPortal( targetPos, rot, self.secondColor )
			self.secondPortalFired = true
		end
	end
end

function PortalGun.server_onDestroy( self )
	if self.firstPortal and self.firstPortal:exists() then
		self.firstPortal:destroy()
	end
	if self.secondPortal and self.secondPortal:exists() then
		self.secondPortal:destroy()
	end
end



function PortalGun.client_onEquippedUpdate( self, primary, secondary, forceBuild )
	if primary == 1 then	--left mouse button
		self:cl_shootPortal( 1 )	--shoot first portal
	end
	if secondary == 1 then	--right mouse button
		self:cl_shootPortal( 2 )	--shoot second portal
	end
	return true, true
end

function PortalGun.cl_shootPortal( self, portalType )
	local valid, result = sm.localPlayer.getRaycast( 1000 )	--raycast
	if valid then
		local pos = result.pointWorld		--get the position and normal of the hit surface, then tell the server to spawn a portal there
		local normal = result.normalWorld
		self.network:sendToServer( "sv_shootPortal", { portalType, pos.x, pos.y, pos.z, normal.x, normal.y, normal.z } )	--separate the values to use less network data
	end
end
