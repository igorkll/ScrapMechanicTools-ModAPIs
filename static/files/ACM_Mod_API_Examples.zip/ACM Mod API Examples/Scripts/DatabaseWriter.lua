
local ACM = sm["6adc7c70-de63-4f47-afbf-018220f548d4"]

DatabaseWriter = class()

function DatabaseWriter.server_onCreate( self )
	local description = sm.json.open( "$CONTENT_DATA/description.json" )
	self.databaseKey = sm.uuid.new( description.localId )				--get the content UUID from the mod description, to use as database key
	
	if not ACM.database.isValidKey( self.databaseKey ) then				--If the key isn't registered in the db yet
		print( "Mod key not valid, registering new key" )
		local success, key = ACM.database.setModKey( self.databaseKey )	--try to set the key
		if success then
			print( "Successfully set mod key:", key )
		else
			sm.log.error( "Failed to set mod key!" )
		end
	end
end

function DatabaseWriter.sv_write( self, _, player )
	ACM.database.setModData( self.databaseKey, "ExampleCategory", "Example data" )	--write example data to the database with the database key
	self.network:sendToClient( player, "cl_success" )
end




function DatabaseWriter.client_canInteract( self )
	local use = sm.gui.getKeyBinding( "Use", true )
	sm.gui.setInteractionText( "", use, "Write example data to database" )
	return true
end

function DatabaseWriter.client_onInteract( self, char, lookAt )
	if lookAt then
		self.network:sendToServer( "sv_write" )
	end
end

function DatabaseWriter.cl_success( self )
	sm.gui.chatMessage( "Data has been set!" )
end



