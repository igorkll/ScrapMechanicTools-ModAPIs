
local ACM = sm["6adc7c70-de63-4f47-afbf-018220f548d4"]

LaserReceiver = class()

LaserReceiver.connectionOutput = 1
LaserReceiver.maxChildCount = 255	--allow child/outgoing logic connections

function LaserReceiver.server_onCreate( self )
	ACM.laser.addReceiver( self.interactable )	--register the receiver upon being placed
end

function LaserReceiver.server_onDestroy( self )
	ACM.laser.removeReceiver( self.interactable )	--un-register the receiver if it is destroyed/erased
end
