
local ACM = sm["6adc7c70-de63-4f47-afbf-018220f548d4"]

AutoSavePoint = class()

AutoSavePoint.connectionInput = 1
AutoSavePoint.maxParentCount = 2

function AutoSavePoint.server_onCreate( self )
	self.sv_wasActive = false
end

function AutoSavePoint.server_onFixedUpdate( self, dt )
	local parents = self.interactable:getParents()
	local p1, p2 = parents[1], parents[2]

	if not self.sv_wasActive then
		local active
		if p1 and p1.active then	--get the active parent
			active = p1
		elseif p2 and p2.active then
			active = p2
		end
		if active then
			self.sv_wasActive = true
			local color = tostring( active.shape.color )	--if there is an active parent, get its color
			if color == "eeeeeeff" then					--white input saves the map
				self:sv_save()
			elseif color == "222222ff" then				--black input loads the save
				self:sv_load()
			end
		end
	elseif not ( p1 and p1.active ) and not ( p2 and p2.active ) then
		self.sv_wasActive = false
	end
end

function AutoSavePoint.sv_save( self )
	ACM.map.save( "autosave", false, true )	--create a hidden save point with the name "autosave". Last param is true to override existing saves
end

function AutoSavePoint.sv_load( self )
	local result = ACM.map.load( "autosave" )	--load the previously saved save point. Spawnpoint disable is default so 2nd param isn't needed
	if not result then
		self.network:sendToClients( "cl_loadFailed" )	--notify players if loading the save failed
	end
end


function AutoSavePoint.cl_loadFailed( self )
	sm.gui.chatMessage( "Failed to load save point! Save point did not exist." )
end




