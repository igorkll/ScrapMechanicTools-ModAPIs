
local ACM = sm["6adc7c70-de63-4f47-afbf-018220f548d4"]

GravityChanger = class()

function GravityChanger.server_onCreate( self )
	ACM.settings.physics.setPlayerGravity( -3 )	
end
