
local ACM = sm["6adc7c70-de63-4f47-afbf-018220f548d4"]

DebugEnabler = class()

function DebugEnabler.sv_enable( self, _, player )
	ACM.mod.enableDebugMode()
	self.network:sendToClient( player, "cl_msg", 1 )
end

function DebugEnabler.sv_getMode( self, _, player )
	local state = ACM.mod.isInDebugMode()
	local code = state and 2 or 3
	self.network:sendToClient( player, "cl_msg", code )
end



function DebugEnabler.client_canInteract( self )
	local use = sm.gui.getKeyBinding( "Use", true )
	local tinker = sm.gui.getKeyBinding( "Tinker", true )

	sm.gui.setInteractionText( "", use, "Enable debug mode" )
	sm.gui.setInteractionText( "", tinker, "Show debug mode state" )

	return true
end

function DebugEnabler.client_onInteract( self, char, lookAt )
	if lookAt then
		self.network:sendToServer( "sv_enable" )
	end
end

function DebugEnabler.client_onTinker( self, char, lookAt )
	if lookAt then
		self.network:sendToServer( "sv_getMode" )
	end
end

function DebugEnabler.cl_msg( self, code )
	local msg = ""
	if code == 1 then
		msg = "ACM is now in debug mode. ACM.util.debugPrint is enabled."
	elseif code == 2 then
		msg = "Debug mode is enabled."
	elseif code == 3 then
		msg = "Debug mode is not enabled."
	end
	sm.gui.chatMessage( msg )
end
