
local ACM = sm["6adc7c70-de63-4f47-afbf-018220f548d4"]

SimpleLaser = class()

SimpleLaser.connectionInput = 1
SimpleLaser.connectionOutput = 1

SimpleLaser.maxParentCount = 1
SimpleLaser.maxChildCount = 1

function SimpleLaser.server_onCreate( self )
	self.lazer = ACM.laser.createLaser()	--for the host, server and client are synced so only server needs to create a laser
end

function SimpleLaser.server_onFixedUpdate( self, dt )
	local parent = self.interactable:getSingleParent()
	local active = parent and parent.active or false

	if active then
		self.lazer:sv_fire( self.shape.worldPosition, self.shape.at, 20, true )	--Fire the laser on the server to let it calculate/activate laser receivers
	end																			--Firing in non-custom mode (last arg is true) lets the laser calculate everything by itself
end



function SimpleLaser.client_onCreate( self )
	if not self.lazer then						--if the client is NOT the host (and thus doesn't have a laser yet), create their own local laser
		self.lazer = ACM.laser.createLaser()
	end
end

function SimpleLaser.client_onFixedUpdate( self, dt )
	local parent = self.interactable:getSingleParent()
	local active = parent and parent.active or false

	if active then
		self.lazer:cl_fire( self.shape.worldPosition, self.shape.at, 20, self.shape.color )	--fire the laser on the client to make the laser beam appear in the world
	elseif self.lazer.active then
		self.lazer:cl_stop()	--Stop the laser if the parent logic is off. This is needed to make the laser beam disappear when the laser is turned off.
	end

end

function SimpleLaser.client_onDestroy( self )
	self.lazer:cl_destroy()		--Destroy the laser if the interactable part is destroyed/erased/etc.
end

